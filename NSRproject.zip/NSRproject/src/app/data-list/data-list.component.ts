import { Component, OnInit, OnDestroy, ViewChild, ElementRef, HostListener } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Dataservice } from '../data-service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-data-list',
  templateUrl: './data-list.component.html',
  styleUrls: ['./data-list.component.css']
})
export class DataListComponent implements OnInit, OnDestroy
{
  products: any = [];
  detail=true;
  list:string;
  private subscription: Subscription;
  
  mens: {name:string,image: string,price: string}[] = [];
  womens: {name:string,image: string,price: string}[] = [];
  kids: {name:string,image: string,price: string}[] = [];

  x:number;
  constructor(private httpClient: HttpClient,private router: Router,private route: ActivatedRoute,private dataservice: Dataservice){}


  ngOnInit(){
   
    console.log("offset",window.pageYOffset);
  
    setTimeout(() => {
    //   this.menheight = document.getElementById("demo1").offsetTop;
    //   this.womenheight = document.getElementById("demo").offsetTop;
    //   this.kidsheight = document.getElementById("demo2").offsetTop;
    //   this.dataservice.heightofdivmethod({menarea: this.menheight, womenarea: this.womenheight,kidarea: this.kidsheight});
    // console.log(this.menheight,this.womenheight);
    }, 1000);

  

    this.dataservice.listenable.subscribe(
      (value: boolean) =>
      {
        this.detail = value;
      }
    )

    this.subscription = this.httpClient.get("assets/data.json").subscribe(data =>{
      this.products = data;
      this.mens = this.products.dataobj.mens;
      this.womens = this.products.dataobj.womens;
      this.kids = this.products.dataobj.kids;
      console.log("in list",this.mens); 
    })

  
    this.x = (Math.floor((Math.random() * 10) + 1)) % 3 ;

  }
  

 
  value: { number: number; name: string; }
  onbuymethod(number: number,name: string)
  {
   this.value = {number,name};
    console.log("navigate methd")
    // this.detail = false;
    this.dataservice.subjectmethod(false);
    this.dataservice.detailenablemethod(true);
    this.dataservice.listenablemethod(false);
    this.dataservice.datadetailmethod(this.value);
    window.scrollTo(0,0);
    // this.router.navigate(['datadetail',number,name]);
  }


  currentActive = 'none';

  menheight=0;
  womenheight=0;
  kidsheight=0;
  defaultdivheight1=0;
  defaultdivheight2=0; 
  defaultdivheight3=0;

  ngAfterViewInit() {
    this.menheight = document.getElementById("demo1").offsetTop;
    this.womenheight = document.getElementById("demo").offsetTop;
    this.kidsheight = document.getElementById("demo2").offsetTop;
    this.dataservice.heightofdivmethod({menarea: this.menheight, womenarea: this.womenheight,kidarea: this.kidsheight});
  console.log("man",this.menheight,this.womenheight);
  }

  scrollToElement() {
    // scrollToElement Code :)
  }
 
  @HostListener('window:scroll', ['$event'])
  checkOffsetTop() {
    this.menheight = document.getElementById("demo1").offsetTop;
    this.womenheight = document.getElementById("demo").offsetTop;
    this.kidsheight = document.getElementById("demo2").offsetTop;
    this.defaultdivheight1 = document.getElementById("demo").offsetHeight;
    this.defaultdivheight2 = document.getElementById("demo1").offsetHeight;
    this.defaultdivheight3 = document.getElementById("demo2").offsetHeight;

    this.dataservice.heightofdivmethod({menarea: this.menheight, womenarea: this.womenheight,kidarea: this.kidsheight});
    
    if (window.pageYOffset >= this.menheight-54 && window.pageYOffset < this.menheight-54+this.defaultdivheight1) {
      this.currentActive = 'men';
      
    } else if (window.pageYOffset >= this.womenheight-54 && window.pageYOffset < this.womenheight-54+this.defaultdivheight2) {
      this.currentActive = 'women';
    
    } else if (window.pageYOffset >= this.kidsheight-54 && window.pageYOffset < this.kidsheight-54+this.defaultdivheight3) {
      this.currentActive = 'kid'
    }
   else if (window.pageYOffset >= this.kidsheight-54) {
    this.currentActive = 'about';
  }
      console.log("---",this.menheight,this.womenheight,this.kidsheight)
     console.log("windo",window.pageYOffset,"current",this.currentActive);
    // console.log("doc ",document.documentElement.clientTop);
    this.dataservice.headeractive.next(this.currentActive);
    
  } 
 
 
  ngOnDestroy()
  {
    this.subscription.unsubscribe();
  }

}
