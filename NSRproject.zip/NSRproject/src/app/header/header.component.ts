import { Component, OnInit, HostListener } from '@angular/core';
import { Dataservice } from '../data-service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor(private dataservice: Dataservice) { }
  animation = false;
  activelink:string;
  topofmenarea = 0;
  topofwomenarea = 0;
  topofkidarea = 0;
  toggle=false
  

  @HostListener("window:scroll", ["$event"])
  onWindowScroll() {
    // console.log(document.documentElement.scrollTop);
if(document.documentElement.scrollTop >=75 && document.documentElement.scrollTop <=95 ) {
  this.animation=!this.animation


} }


  gotohome()
  {
    scrollTo(0,0);
    this.dataservice.ordermethod(false);
    this.dataservice.detailenablemethod(false);
    this.dataservice.listenablemethod(true);
    this.dataservice.subjectmethod(true);
    this.dataservice.headeractive.next('none');
    console.log("entering")
   setTimeout(() => {
     this.activelink = 'none';
   }, 500);
   
    // this.toggle=!this.toggle;
   
  }



  size: { menarea: number; womenarea: number;kidarea: number }

  ngOnInit(): void {

    this.dataservice.listenable.subscribe(
      (value:boolean)=>
      {
        if(value === false)
        {
          console.log("false");
          this.activelink = 'none';
        }
      }
    )
    window.scrollTo(0,2);

    this.dataservice.heightofdiv.subscribe(
      ( size: { menarea: number; womenarea: number;kidarea: number }) =>
      {
        // console.log("kid",size.kidarea,size.menarea,size.womenarea);
        this.topofkidarea = size.kidarea;
        this.topofmenarea = size.menarea;
        this.topofwomenarea = size.womenarea;
       
      }
    )
    this.dataservice.headeractive.subscribe(
      (value: string) =>
     {  this.activelink = value.toString();
      console.log("inheader",this.activelink);}

  
    )
  }
  menscroll()
  {
    this.showMenu();
    window.scrollTo(0,this.topofmenarea-30);
  }
  womenscroll()
  {
    this.showMenu();
    window.scrollTo(0,this.topofwomenarea);
  }
  kidscroll()
  {
    this.showMenu();
    window.scrollTo(0,this.topofkidarea);
  }


showMenu(){
    this.toggle=!this.toggle
  }
  
}

