import { ScrollbarDirective } from './scrollbar.directive';

describe('ScrollbarDirective', () => {
  it('should create an instance', () => {
    const directive = new ScrollbarDirective();
    expect(directive).toBeTruthy();
  });
});
