import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Dataservice } from '../data-service';
import { HttpClient } from '@angular/common/http';
import { Subscription } from 'rxjs';


@Component({
  selector: 'app-data-detail',
  templateUrl: './data-detail.component.html',
  styleUrls: ['./data-detail.component.css']
})
export class DataDetailComponent implements OnInit, OnDestroy {

  constructor(private httpClient: HttpClient,private router: Router,private route: ActivatedRoute,private dataservice: Dataservice) { }
  id: number;
  type:string;
  products: any = [];
  value = false;
  data: {id:number,type:string,name:string,image: string,price: string,estimatedprice: string,description: string,clothtype:string,color:string};
  private subscription: Subscription;
  ngOnInit(): void {

    
      window.scrollTo(0,0);

      this.dataservice.datadetail.subscribe(
        ( value: { number: number; name: string; })=>
        {
          console.log("enter");
          this.id = value.number.valueOf();
          console.log(typeof this.id);
          this.type =value.name.toString();
          console.log(typeof this.type);
          this.value = true;
          
          if(this.type === "women")
          this.data = this.products.dataobj.womens[this.id];
          if(this.type === "men")
          this.data = this.products.dataobj.mens[this.id];
          if(this.type === "kids")
          this.data = this.products.dataobj.kids[this.id];

        }
      )
  
      this.subscription = this.dataservice.detailenable.subscribe(
        (value: boolean) =>
        {
          console.log("data  value",value);
          if(value)
          this.value = true;
          else
          this.value = false;
        }
      )
    

    // this.subscription = this.route.paramMap.subscribe(
    //   (params: Params) =>
    //   {
    //     // console.log("enter");
    //     // this.id = +params.get('id');
    //     // console.log(this.id);
    //     // this.type =params.get('type');
    //     // console.log(this.type);

    //   }
    // )

    this.httpClient.get("assets/data.json").subscribe(data =>{
      this.products = data;
      //  if(this.type === "women")
      //   this.data = this.products.dataobj.womens[this.id];
      //   if(this.type === "men")
      //   this.data = this.products.dataobj.mens[this.id];
      //   if(this.type === "kids")
      //   this.data = this.products.dataobj.kids[3];
        
        console.log("final",this.data);
    }) ;


    var countDownDate = new Date("Jan 5, 2021 15:37:25").getTime();

var x = setInterval(function() {
var now = new Date().getTime();
    
  var distance = countDownDate - now;
  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);
  // document.getElementById("demo").innerHTML = hours + "h "
  // + minutes + "m " + seconds + "s ";
  if (distance < 0) {
    clearInterval(x);
    document.getElementById("demo").innerHTML = "EXPIRED";
  }
}, 1000);

  }

  order()
  {
    this.dataservice.ordermethod(true);
    this.dataservice.detailenablemethod(false);
  }

  ngOnDestroy()
  {
    this.subscription.unsubscribe();
  }
  

}
