import { Component, OnInit } from '@angular/core';
import { Dataservice } from '../data-service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-orderinstruction',
  templateUrl: './orderinstruction.component.html',
  styleUrls: ['./orderinstruction.component.css']
})
export class OrderinstructionComponent implements OnInit {

  constructor(private dataservice: Dataservice) { }

  subscription: Subscription
  value = false;
  ngOnInit(): void {

    window.scrollTo(0,0);

    this.subscription = this.dataservice.orderenable.subscribe(
      (value: boolean) =>
      {
        console.log("order  value",value);
        if(value)
        this.value = true;
        else
        this.value = false;
      }
    )
    
  }

}
