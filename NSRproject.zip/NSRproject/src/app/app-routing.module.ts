
import { Routes, RouterModule, Router } from '@angular/router';
import { DataDetailComponent } from './data-detail/data-detail.component';
import { NgModule } from '@angular/core';
import { DataListComponent } from './data-list/data-list.component';
import { FooterComponent } from './footer/footer.component';
import { OrderinstructionComponent } from './orderinstruction/orderinstruction.component';
import { MainComponent } from './main/main.component';
import { CarouselComponent } from './carousel/carousel.component';

const appRoutes: Routes = [
 
  { path: 'home', redirectTo: 'carousel', pathMatch:'full' },
  { path: 'carousel',component:CarouselComponent },
   { path: 'datalist/:type',component:DataListComponent },
   { path: 'datalist/kids',component:DataListComponent },
   { path: 'orderdetail',component:OrderinstructionComponent },
   { path: 'footer',component:FooterComponent },
  { path: 'datadetail/:id/:type',component:DataDetailComponent },
  { path: 'new',component:DataDetailComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(appRoutes)],
  exports: [RouterModule]
})


export class AppRoutingModule { }
