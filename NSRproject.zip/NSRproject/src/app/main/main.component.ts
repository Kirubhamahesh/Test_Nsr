import { Component, OnInit, ViewChild, ElementRef, HostListener } from '@angular/core';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit {

  animation = false;
  value = false;
  @HostListener("window:scroll", ["$event"])
  onWindowScroll() {
    // console.log(document.documentElement.scrollTop);
if(document.documentElement.scrollTop >=75 && document.documentElement.scrollTop <=95 ) {
  this.animation=!this.animation


} }

    @ViewChild('content') element: ElementRef;
  
    ngOnInit(): void {
   
    }

    ngAfterViewInit(): void {
      //Called after ngAfterContentInit when the component's view has been initialized. Applies to components only.
      // console.log(this.element.nativeElement);
      // this.open(this.element);
    }
    
    closeResult = '';
  
    constructor(private modalService: NgbModal) {}
  
    open(content) {
      this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
        this.closeResult = `Closed with: ${result}`;
      }, (reason) => {
        this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
      });
    }
  
    private getDismissReason(reason: any): string {
      if (reason === ModalDismissReasons.ESC) {
        return 'by pressing ESC';
      } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
        return 'by clicking on a backdrop';
      } else {
        return `with: ${reason}`;
      }
    }


    @HostListener('window:scroll', ['$event'])
    doSomething(event) {

      if(window.pageYOffset > 1000)
      {
        this.value = true;
      }
      else
      this.value = false;
    var winScroll = document.documentElement.scrollTop;
    var height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
    var scrolled = (winScroll / height) * 100;
    
    // console.log("Scroll %", scrolled);
    document.getElementById("scrollBar").style.width = scrolled + "%";
    }

    gototop()
    {
      window.scrollTo(0,0);
    }
    
    
  }
  